import requests
import json
import threading
import time

lock = threading.Lock()


class R(threading.Thread):
    proxy = {
        'https': '127.0.0.1:1080',
        'https': '120.79.27.253:443',
        'https': '147.70.27.153:443',
        'https': '157.230.47.75'
    }
    url = "https://find.godaddy.com/domainsapi/v1/search/exact?q={a}.gs&key=dpp_search&pc=&ptl="
    h = {
        'accept': 'application/json, text/plain, */*',
        'origin': 'https://sg.godaddy.com',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
    }

    def __init__(self, doname):
        threading.Thread.__init__(self)
        self.domain = doname

    def run(self):
        r = requests.get(url=R.url.format(a=self.domain), headers=R.h, proxies=R.proxy)
        j = json.loads(r.text)
        w = {
            self.domain: True if j["ExactMatchDomain"]["IsAvailable"] else False
        }
        print(self.domain)
        lock.acquire()
        con.append(w)
        lock.release()


def main(n):
    donames = json.load(open("2.json", "r", encoding='utf-8'))
    for doname in donames:
        thread = R(doname)
        thread.start()
        threads.append(thread)
        time.sleep(n)


con = list()
threads = list()
if __name__ == '__main__':
    main(0.2)
    for i in threads:
        i.join()
    f = open("t.json", "w", encoding='utf-8')
    f.write(json.dumps(con))
    f.close()
