class Reader(object):
    def __init__(self, tokens, position=0):
        self.tokens = tokens
        self.position = position

    def next(self):
        self.position += 1
        return self.tokens[self.position-1]  #列表

    def peek(self):
            return self.tokens[self.position]

def read_str(var):
    tokens = tokenize(var)
    tokens = Reader()
    return read_form(tokens)


#def tokenize(str):
    #tre = re.compile(r"""[\s,]*(~@|[\[\]{}()'`~^@]|"(?:[\\].|[^\\"])*"?|;.*|[^\s\[\]{}()'"`@,;]+)""");
    #return [t for t in re.findall(tre, str) if t[0] != ';']
    #正则

def read_form(reader):
    reader = Reader()
    token = reader.peek()

    if taken == '(':
        return read_list(reader)
    else:
        return read_atom(reader)

def read_list(reader):
    reader = Reader()
    token = reader.peek()
    aim_list = List()    # List方法

    while token != ")":
        aim_list.append(read_form(reader))
        token = reader.peek()

    return aim_list

#def read_atom(reader):
    #int_re = re.compile(r"-?[0-9]+$")
    #float_re = re.compile(r"-?[0-9][0-9.]*$")
    #token = reader.next()
    #if re.match(int_re, token):     return int(token)
    #elif re.match(float_re, token): return int(token)
    #elif token[0] == '"':
        #if token[-1] == '"':        return _s2u(_unescape(token[1:-1]))
        #else:                       raise Exception("expected '\"', got EOF")
    #elif token[0] == ':':           return _keyword(token[1:])
    #elif token == "nil":            return None
    #elif token == "true":           return True
    #elif token == "false":          return False
    #else:                           return _symbol(token)
# 正则
