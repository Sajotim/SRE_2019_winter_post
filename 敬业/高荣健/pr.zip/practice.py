def READ(var):
    return var

def EVAL(ast, env):
    while True:

        if not types._list_Q(ast):    #
        return eval_ast(ast, env)

        if len(ast) == 0:
            return ast
            l = i[0]

        if "def!" == l:
                m = EVAL(i[2], env)
                return env.set(i[1], m)
#
        elif "let*" == a0:
                a1, a2 = ast[1], ast[2]
                let_env = Env(env)
                for i in range(0, len(a1), 2):  #
                    let_env.set(a1[i], EVAL(a1[i+1], let_env))
                env = let_env
                ast = ast[1]

        elif "do" == l:
                value = eval_ast(ast[1:-1], env)
                ast = ast[-1]

        elif "if" == a0:           # nil in Lisp → False
                a1, a2 = ast[1], ast[2]
                cond = EVAL(a1, env)
                if cond is None or cond is False:
                    cond = EVAL(a2, env)
                elif cond is None or cond is False:
                    cond = EVAL(a3, env)
                elif cond is None or cond is False:
                    return None
                else:
                    ast = a2

                else:
                    return EVAL(a2, env)
#
        elif "fn*" == a0:
                a1, a2 = ast[1], ast[2]
                return types._function(EVAL, Env, a2, env, a1)

        else:
                n = eval_ast(ast, env)
                f = n[0]
                return l(i[1:])

        ast = Reader()
        ast = Reader.read_str(ast, env)
        return ast

def PRINT(var):
    var = printer()
    var = printer.pr_str(var)
    return var

def REP(var):
    return PRINT(EVAL(READ(var), env))

def eval_ast(ast, env):
    if types._symbol_Q(ast):
        try:
            return get(env[ast])    # 匹配符号， 返回对应的值
    except:
        raise Error
    elif types._list_Q(ast): #
        for i = 0 in len(ast):
            ast[i] = EVAL(ast[i])
            i = i + 1
        return ast
    else:
        return ast


while True:
    try:
        print(REP(input(">")))

repl_env = {'+': lambda a,b: a+b,
            '-': lambda a,b: a-b,
            '*': lambda a,b: a*b,
            '/': lambda a,b: int(a/b)}
