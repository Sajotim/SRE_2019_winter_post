class Env(object):
    def __init__(self, outer):
        self.outer = outer
        self.data = {}

    def set(self, key, value):
        value = self.data[key]

    def find(self, key):
        if key in self.data:
            return self.data
        elif self.outer != nil:
            return self.outer.find(self, key)
        else:
            return None

    def get(self, key):
        env = find(self, key)

        if not env:
            raise NotFound
